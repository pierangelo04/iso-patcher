@echo off
call create-rr-pal-compact.bat nopause
call create-rr-usa-compact.bat nopause
call create-rr-jpn-compact.bat nopause

if /%1 == /nopause goto nopause
 pause
:nopause
